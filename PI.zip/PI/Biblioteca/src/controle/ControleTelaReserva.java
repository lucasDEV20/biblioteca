/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controle;

import classes.Reserva;
import interfaces.ICRUDReserva;

/**
 *
 * @author vovostudio
 */
public class ControleTelaReserva {
     private ICRUDReserva controleReserva = null;
    private Reserva reserva = null;
}
