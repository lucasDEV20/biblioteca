/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package enumeradores;

/**
 *
 * @author vovostudio
 */
public enum EnumAcao {
    Incluir,
    Editar,
    Excluir,
    Incluir_Emprestimo,
    Incluir_Reserva,
    Editar_Emprestimo,
    Editar_Reserva,
    Importar_CDD
}
